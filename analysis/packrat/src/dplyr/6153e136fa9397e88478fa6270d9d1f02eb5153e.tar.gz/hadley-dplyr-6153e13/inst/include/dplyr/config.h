#ifndef DPLYR_CONFIG_H
  #define DPLYR_CONFIG_H

  #ifndef DPLYR_MIN_INTERUPT_SIZE
    #define DPLYR_MIN_INTERUPT_SIZE 10000
  #endif

  #ifndef DPLYR_INTERUPT_TIMES
    #define DPLYR_INTERUPT_TIMES 10
  #endif

#endif


